import PublicBookingController from './PublicBookingController'
const Api = {
    PublicBookingController: Object.assign(PublicBookingController, PublicBookingController),
}

export default Api