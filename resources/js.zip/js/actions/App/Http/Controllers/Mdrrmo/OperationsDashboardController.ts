import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
const OperationsDashboardController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: OperationsDashboardController.url(options),
    method: 'get',
})

OperationsDashboardController.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/operations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
OperationsDashboardController.url = (options?: RouteQueryOptions) => {
    return OperationsDashboardController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
OperationsDashboardController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: OperationsDashboardController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
OperationsDashboardController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: OperationsDashboardController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
    const OperationsDashboardControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: OperationsDashboardController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
        OperationsDashboardControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: OperationsDashboardController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
        OperationsDashboardControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: OperationsDashboardController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    OperationsDashboardController.form = OperationsDashboardControllerForm
export default OperationsDashboardController