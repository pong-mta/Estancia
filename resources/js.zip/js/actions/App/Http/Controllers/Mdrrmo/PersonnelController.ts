import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::index
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:15
 * @route '/mdrrmo/personnel'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/personnel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::index
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:15
 * @route '/mdrrmo/personnel'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::index
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:15
 * @route '/mdrrmo/personnel'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::index
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:15
 * @route '/mdrrmo/personnel'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::index
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:15
 * @route '/mdrrmo/personnel'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::index
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:15
 * @route '/mdrrmo/personnel'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::index
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:15
 * @route '/mdrrmo/personnel'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::store
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:89
 * @route '/mdrrmo/personnel'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/mdrrmo/personnel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::store
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:89
 * @route '/mdrrmo/personnel'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::store
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:89
 * @route '/mdrrmo/personnel'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::store
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:89
 * @route '/mdrrmo/personnel'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::store
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:89
 * @route '/mdrrmo/personnel'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::show
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:149
 * @route '/mdrrmo/personnel/{personnel}'
 */
export const show = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/personnel/{personnel}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::show
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:149
 * @route '/mdrrmo/personnel/{personnel}'
 */
show.url = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { personnel: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { personnel: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    personnel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        personnel: typeof args.personnel === 'object'
                ? args.personnel.id
                : args.personnel,
                }

    return show.definition.url
            .replace('{personnel}', parsedArgs.personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::show
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:149
 * @route '/mdrrmo/personnel/{personnel}'
 */
show.get = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::show
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:149
 * @route '/mdrrmo/personnel/{personnel}'
 */
show.head = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::show
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:149
 * @route '/mdrrmo/personnel/{personnel}'
 */
    const showForm = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::show
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:149
 * @route '/mdrrmo/personnel/{personnel}'
 */
        showForm.get = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::show
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:149
 * @route '/mdrrmo/personnel/{personnel}'
 */
        showForm.head = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::update
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:159
 * @route '/mdrrmo/personnel/{personnel}'
 */
export const update = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/mdrrmo/personnel/{personnel}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::update
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:159
 * @route '/mdrrmo/personnel/{personnel}'
 */
update.url = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { personnel: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { personnel: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    personnel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        personnel: typeof args.personnel === 'object'
                ? args.personnel.id
                : args.personnel,
                }

    return update.definition.url
            .replace('{personnel}', parsedArgs.personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::update
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:159
 * @route '/mdrrmo/personnel/{personnel}'
 */
update.put = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::update
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:159
 * @route '/mdrrmo/personnel/{personnel}'
 */
update.patch = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::update
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:159
 * @route '/mdrrmo/personnel/{personnel}'
 */
    const updateForm = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::update
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:159
 * @route '/mdrrmo/personnel/{personnel}'
 */
        updateForm.put = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::update
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:159
 * @route '/mdrrmo/personnel/{personnel}'
 */
        updateForm.patch = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::deactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:221
 * @route '/mdrrmo/personnel/{personnel}/deactivate'
 */
export const deactivate = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: deactivate.url(args, options),
    method: 'patch',
})

deactivate.definition = {
    methods: ["patch"],
    url: '/mdrrmo/personnel/{personnel}/deactivate',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::deactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:221
 * @route '/mdrrmo/personnel/{personnel}/deactivate'
 */
deactivate.url = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { personnel: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { personnel: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    personnel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        personnel: typeof args.personnel === 'object'
                ? args.personnel.id
                : args.personnel,
                }

    return deactivate.definition.url
            .replace('{personnel}', parsedArgs.personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::deactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:221
 * @route '/mdrrmo/personnel/{personnel}/deactivate'
 */
deactivate.patch = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: deactivate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::deactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:221
 * @route '/mdrrmo/personnel/{personnel}/deactivate'
 */
    const deactivateForm = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deactivate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::deactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:221
 * @route '/mdrrmo/personnel/{personnel}/deactivate'
 */
        deactivateForm.patch = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deactivate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deactivate.form = deactivateForm
/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::reactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:239
 * @route '/mdrrmo/personnel/{personnel}/reactivate'
 */
export const reactivate = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reactivate.url(args, options),
    method: 'patch',
})

reactivate.definition = {
    methods: ["patch"],
    url: '/mdrrmo/personnel/{personnel}/reactivate',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::reactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:239
 * @route '/mdrrmo/personnel/{personnel}/reactivate'
 */
reactivate.url = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { personnel: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { personnel: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    personnel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        personnel: typeof args.personnel === 'object'
                ? args.personnel.id
                : args.personnel,
                }

    return reactivate.definition.url
            .replace('{personnel}', parsedArgs.personnel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::reactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:239
 * @route '/mdrrmo/personnel/{personnel}/reactivate'
 */
reactivate.patch = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reactivate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::reactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:239
 * @route '/mdrrmo/personnel/{personnel}/reactivate'
 */
    const reactivateForm = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reactivate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\PersonnelController::reactivate
 * @see app/Http/Controllers/Mdrrmo/PersonnelController.php:239
 * @route '/mdrrmo/personnel/{personnel}/reactivate'
 */
        reactivateForm.patch = (args: { personnel: number | { id: number } } | [personnel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reactivate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reactivate.form = reactivateForm
const PersonnelController = { index, store, show, update, deactivate, reactivate }

export default PersonnelController