import OperationsDashboardController from './OperationsDashboardController'
import AmbulanceController from './AmbulanceController'
import PersonnelController from './PersonnelController'
import BookingRequestController from './BookingRequestController'
import OperationController from './OperationController'
const Mdrrmo = {
    OperationsDashboardController: Object.assign(OperationsDashboardController, OperationsDashboardController),
AmbulanceController: Object.assign(AmbulanceController, AmbulanceController),
PersonnelController: Object.assign(PersonnelController, PersonnelController),
BookingRequestController: Object.assign(BookingRequestController, BookingRequestController),
OperationController: Object.assign(OperationController, OperationController),
}

export default Mdrrmo