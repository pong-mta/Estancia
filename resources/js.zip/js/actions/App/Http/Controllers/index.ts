import Api from './Api'
import PublicTrackingController from './PublicTrackingController'
import Admin from './Admin'
import Mdrrmo from './Mdrrmo'
import Settings from './Settings'
const Controllers = {
    Api: Object.assign(Api, Api),
PublicTrackingController: Object.assign(PublicTrackingController, PublicTrackingController),
Admin: Object.assign(Admin, Admin),
Mdrrmo: Object.assign(Mdrrmo, Mdrrmo),
Settings: Object.assign(Settings, Settings),
}

export default Controllers