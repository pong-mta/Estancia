import OfficeController from './OfficeController'
import UserController from './UserController'
import WorkflowController from './WorkflowController'
import WorkflowStepController from './WorkflowStepController'
import WorkflowActionController from './WorkflowActionController'
import DocumentController from './DocumentController'
import DocumentAttachmentController from './DocumentAttachmentController'
import PendingApprovalController from './PendingApprovalController'
import DocumentHistoryController from './DocumentHistoryController'
import ProcurementController from './ProcurementController'
import SupplierController from './SupplierController'
import SupplierQuotationController from './SupplierQuotationController'
const Admin = {
    OfficeController: Object.assign(OfficeController, OfficeController),
UserController: Object.assign(UserController, UserController),
WorkflowController: Object.assign(WorkflowController, WorkflowController),
WorkflowStepController: Object.assign(WorkflowStepController, WorkflowStepController),
WorkflowActionController: Object.assign(WorkflowActionController, WorkflowActionController),
DocumentController: Object.assign(DocumentController, DocumentController),
DocumentAttachmentController: Object.assign(DocumentAttachmentController, DocumentAttachmentController),
PendingApprovalController: Object.assign(PendingApprovalController, PendingApprovalController),
DocumentHistoryController: Object.assign(DocumentHistoryController, DocumentHistoryController),
ProcurementController: Object.assign(ProcurementController, ProcurementController),
SupplierController: Object.assign(SupplierController, SupplierController),
SupplierQuotationController: Object.assign(SupplierQuotationController, SupplierQuotationController),
}

export default Admin