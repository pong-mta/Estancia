import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::store
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:16
 * @route '/admin/procurement/{procurement}/quotations'
 */
export const store = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/procurement/{procurement}/quotations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::store
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:16
 * @route '/admin/procurement/{procurement}/quotations'
 */
store.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { procurement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    procurement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        procurement: typeof args.procurement === 'object'
                ? args.procurement.id
                : args.procurement,
                }

    return store.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::store
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:16
 * @route '/admin/procurement/{procurement}/quotations'
 */
store.post = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::store
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:16
 * @route '/admin/procurement/{procurement}/quotations'
 */
    const storeForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::store
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:16
 * @route '/admin/procurement/{procurement}/quotations'
 */
        storeForm.post = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::destroy
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:99
 * @route '/admin/procurement/{procurement}/quotations/{quotation}'
 */
export const destroy = (args: { procurement: number | { id: number }, quotation: number | { id: number } } | [procurement: number | { id: number }, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/procurement/{procurement}/quotations/{quotation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::destroy
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:99
 * @route '/admin/procurement/{procurement}/quotations/{quotation}'
 */
destroy.url = (args: { procurement: number | { id: number }, quotation: number | { id: number } } | [procurement: number | { id: number }, quotation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    procurement: args[0],
                    quotation: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        procurement: typeof args.procurement === 'object'
                ? args.procurement.id
                : args.procurement,
                                quotation: typeof args.quotation === 'object'
                ? args.quotation.id
                : args.quotation,
                }

    return destroy.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace('{quotation}', parsedArgs.quotation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::destroy
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:99
 * @route '/admin/procurement/{procurement}/quotations/{quotation}'
 */
destroy.delete = (args: { procurement: number | { id: number }, quotation: number | { id: number } } | [procurement: number | { id: number }, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::destroy
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:99
 * @route '/admin/procurement/{procurement}/quotations/{quotation}'
 */
    const destroyForm = (args: { procurement: number | { id: number }, quotation: number | { id: number } } | [procurement: number | { id: number }, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SupplierQuotationController::destroy
 * @see app/Http/Controllers/Admin/SupplierQuotationController.php:99
 * @route '/admin/procurement/{procurement}/quotations/{quotation}'
 */
        destroyForm.delete = (args: { procurement: number | { id: number }, quotation: number | { id: number } } | [procurement: number | { id: number }, quotation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const SupplierQuotationController = { store, destroy }

export default SupplierQuotationController