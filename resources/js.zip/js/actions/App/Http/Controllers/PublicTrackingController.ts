import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicTrackingController::show
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/track-document',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicTrackingController::show
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicTrackingController::show
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicTrackingController::show
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicTrackingController::show
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicTrackingController::show
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicTrackingController::show
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const PublicTrackingController = { show }

export default PublicTrackingController