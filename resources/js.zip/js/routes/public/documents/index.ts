import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicTrackingController::track
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
export const track = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(options),
    method: 'get',
})

track.definition = {
    methods: ["get","head"],
    url: '/track-document',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicTrackingController::track
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
track.url = (options?: RouteQueryOptions) => {
    return track.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicTrackingController::track
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
track.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: track.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicTrackingController::track
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
track.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: track.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicTrackingController::track
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
    const trackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: track.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicTrackingController::track
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
        trackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: track.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicTrackingController::track
 * @see app/Http/Controllers/PublicTrackingController.php:13
 * @route '/track-document'
 */
        trackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: track.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    track.form = trackForm
const documents = {
    track: Object.assign(track, track),
}

export default documents