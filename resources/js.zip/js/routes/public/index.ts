import documents from './documents'
const publicMethod = {
    documents: Object.assign(documents, documents),
}

export default publicMethod