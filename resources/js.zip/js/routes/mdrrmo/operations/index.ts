import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/operations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\OperationsDashboardController::__invoke
 * @see app/Http/Controllers/Mdrrmo/OperationsDashboardController.php:11
 * @route '/mdrrmo/operations'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::index
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:25
 * @route '/mdrrmo/operations/manage'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/operations/manage',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::index
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:25
 * @route '/mdrrmo/operations/manage'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::index
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:25
 * @route '/mdrrmo/operations/manage'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::index
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:25
 * @route '/mdrrmo/operations/manage'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::index
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:25
 * @route '/mdrrmo/operations/manage'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::index
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:25
 * @route '/mdrrmo/operations/manage'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::index
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:25
 * @route '/mdrrmo/operations/manage'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::store
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:69
 * @route '/mdrrmo/operations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/mdrrmo/operations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::store
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:69
 * @route '/mdrrmo/operations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::store
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:69
 * @route '/mdrrmo/operations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::store
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:69
 * @route '/mdrrmo/operations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::store
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:69
 * @route '/mdrrmo/operations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::show
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:116
 * @route '/mdrrmo/operations/{operation}'
 */
export const show = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/operations/{operation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::show
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:116
 * @route '/mdrrmo/operations/{operation}'
 */
show.url = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { operation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { operation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    operation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        operation: typeof args.operation === 'object'
                ? args.operation.id
                : args.operation,
                }

    return show.definition.url
            .replace('{operation}', parsedArgs.operation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::show
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:116
 * @route '/mdrrmo/operations/{operation}'
 */
show.get = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::show
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:116
 * @route '/mdrrmo/operations/{operation}'
 */
show.head = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::show
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:116
 * @route '/mdrrmo/operations/{operation}'
 */
    const showForm = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::show
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:116
 * @route '/mdrrmo/operations/{operation}'
 */
        showForm.get = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::show
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:116
 * @route '/mdrrmo/operations/{operation}'
 */
        showForm.head = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::assignResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:146
 * @route '/mdrrmo/operations/{operation}/assign-resources'
 */
export const assignResources = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignResources.url(args, options),
    method: 'post',
})

assignResources.definition = {
    methods: ["post"],
    url: '/mdrrmo/operations/{operation}/assign-resources',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::assignResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:146
 * @route '/mdrrmo/operations/{operation}/assign-resources'
 */
assignResources.url = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { operation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { operation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    operation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        operation: typeof args.operation === 'object'
                ? args.operation.id
                : args.operation,
                }

    return assignResources.definition.url
            .replace('{operation}', parsedArgs.operation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::assignResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:146
 * @route '/mdrrmo/operations/{operation}/assign-resources'
 */
assignResources.post = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignResources.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::assignResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:146
 * @route '/mdrrmo/operations/{operation}/assign-resources'
 */
    const assignResourcesForm = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignResources.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::assignResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:146
 * @route '/mdrrmo/operations/{operation}/assign-resources'
 */
        assignResourcesForm.post = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignResources.url(args, options),
            method: 'post',
        })
    
    assignResources.form = assignResourcesForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::dispatch
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:207
 * @route '/mdrrmo/operations/{operation}/dispatch'
 */
export const dispatch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: dispatch.url(args, options),
    method: 'patch',
})

dispatch.definition = {
    methods: ["patch"],
    url: '/mdrrmo/operations/{operation}/dispatch',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::dispatch
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:207
 * @route '/mdrrmo/operations/{operation}/dispatch'
 */
dispatch.url = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { operation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { operation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    operation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        operation: typeof args.operation === 'object'
                ? args.operation.id
                : args.operation,
                }

    return dispatch.definition.url
            .replace('{operation}', parsedArgs.operation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::dispatch
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:207
 * @route '/mdrrmo/operations/{operation}/dispatch'
 */
dispatch.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: dispatch.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::dispatch
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:207
 * @route '/mdrrmo/operations/{operation}/dispatch'
 */
    const dispatchForm = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: dispatch.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::dispatch
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:207
 * @route '/mdrrmo/operations/{operation}/dispatch'
 */
        dispatchForm.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: dispatch.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    dispatch.form = dispatchForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::start
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:296
 * @route '/mdrrmo/operations/{operation}/start'
 */
export const start = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: start.url(args, options),
    method: 'patch',
})

start.definition = {
    methods: ["patch"],
    url: '/mdrrmo/operations/{operation}/start',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::start
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:296
 * @route '/mdrrmo/operations/{operation}/start'
 */
start.url = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { operation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { operation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    operation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        operation: typeof args.operation === 'object'
                ? args.operation.id
                : args.operation,
                }

    return start.definition.url
            .replace('{operation}', parsedArgs.operation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::start
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:296
 * @route '/mdrrmo/operations/{operation}/start'
 */
start.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: start.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::start
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:296
 * @route '/mdrrmo/operations/{operation}/start'
 */
    const startForm = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::start
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:296
 * @route '/mdrrmo/operations/{operation}/start'
 */
        startForm.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::complete
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:321
 * @route '/mdrrmo/operations/{operation}/complete'
 */
export const complete = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

complete.definition = {
    methods: ["patch"],
    url: '/mdrrmo/operations/{operation}/complete',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::complete
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:321
 * @route '/mdrrmo/operations/{operation}/complete'
 */
complete.url = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { operation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { operation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    operation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        operation: typeof args.operation === 'object'
                ? args.operation.id
                : args.operation,
                }

    return complete.definition.url
            .replace('{operation}', parsedArgs.operation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::complete
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:321
 * @route '/mdrrmo/operations/{operation}/complete'
 */
complete.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: complete.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::complete
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:321
 * @route '/mdrrmo/operations/{operation}/complete'
 */
    const completeForm = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::complete
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:321
 * @route '/mdrrmo/operations/{operation}/complete'
 */
        completeForm.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::cancel
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:355
 * @route '/mdrrmo/operations/{operation}/cancel'
 */
export const cancel = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

cancel.definition = {
    methods: ["patch"],
    url: '/mdrrmo/operations/{operation}/cancel',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::cancel
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:355
 * @route '/mdrrmo/operations/{operation}/cancel'
 */
cancel.url = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { operation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { operation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    operation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        operation: typeof args.operation === 'object'
                ? args.operation.id
                : args.operation,
                }

    return cancel.definition.url
            .replace('{operation}', parsedArgs.operation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::cancel
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:355
 * @route '/mdrrmo/operations/{operation}/cancel'
 */
cancel.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: cancel.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::cancel
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:355
 * @route '/mdrrmo/operations/{operation}/cancel'
 */
    const cancelForm = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::cancel
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:355
 * @route '/mdrrmo/operations/{operation}/cancel'
 */
        cancelForm.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::updateResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:183
 * @route '/mdrrmo/operations/{operation}/resources'
 */
export const updateResources = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateResources.url(args, options),
    method: 'patch',
})

updateResources.definition = {
    methods: ["patch"],
    url: '/mdrrmo/operations/{operation}/resources',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::updateResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:183
 * @route '/mdrrmo/operations/{operation}/resources'
 */
updateResources.url = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { operation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { operation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    operation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        operation: typeof args.operation === 'object'
                ? args.operation.id
                : args.operation,
                }

    return updateResources.definition.url
            .replace('{operation}', parsedArgs.operation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\OperationController::updateResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:183
 * @route '/mdrrmo/operations/{operation}/resources'
 */
updateResources.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateResources.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::updateResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:183
 * @route '/mdrrmo/operations/{operation}/resources'
 */
    const updateResourcesForm = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateResources.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\OperationController::updateResources
 * @see app/Http/Controllers/Mdrrmo/OperationController.php:183
 * @route '/mdrrmo/operations/{operation}/resources'
 */
        updateResourcesForm.patch = (args: { operation: number | { id: number } } | [operation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateResources.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateResources.form = updateResourcesForm
const operations = {
    dashboard: Object.assign(dashboard, dashboard),
index: Object.assign(index, index),
store: Object.assign(store, store),
show: Object.assign(show, show),
assignResources: Object.assign(assignResources, assignResources),
dispatch: Object.assign(dispatch, dispatch),
start: Object.assign(start, start),
complete: Object.assign(complete, complete),
cancel: Object.assign(cancel, cancel),
updateResources: Object.assign(updateResources, updateResources),
}

export default operations