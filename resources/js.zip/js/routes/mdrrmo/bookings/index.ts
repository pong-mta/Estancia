import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::index
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:19
 * @route '/mdrrmo/bookings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/bookings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::index
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:19
 * @route '/mdrrmo/bookings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::index
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:19
 * @route '/mdrrmo/bookings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::index
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:19
 * @route '/mdrrmo/bookings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::index
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:19
 * @route '/mdrrmo/bookings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::index
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:19
 * @route '/mdrrmo/bookings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::index
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:19
 * @route '/mdrrmo/bookings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::store
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/mdrrmo/bookings'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/mdrrmo/bookings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::store
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/mdrrmo/bookings'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::store
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/mdrrmo/bookings'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::store
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/mdrrmo/bookings'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::store
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/mdrrmo/bookings'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::show
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:238
 * @route '/mdrrmo/bookings/{booking}'
 */
export const show = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/bookings/{booking}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::show
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:238
 * @route '/mdrrmo/bookings/{booking}'
 */
show.url = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { booking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { booking: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    booking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        booking: typeof args.booking === 'object'
                ? args.booking.id
                : args.booking,
                }

    return show.definition.url
            .replace('{booking}', parsedArgs.booking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::show
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:238
 * @route '/mdrrmo/bookings/{booking}'
 */
show.get = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::show
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:238
 * @route '/mdrrmo/bookings/{booking}'
 */
show.head = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::show
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:238
 * @route '/mdrrmo/bookings/{booking}'
 */
    const showForm = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::show
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:238
 * @route '/mdrrmo/bookings/{booking}'
 */
        showForm.get = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::show
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:238
 * @route '/mdrrmo/bookings/{booking}'
 */
        showForm.head = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::approve
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:248
 * @route '/mdrrmo/bookings/{booking}/approve'
 */
export const approve = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

approve.definition = {
    methods: ["patch"],
    url: '/mdrrmo/bookings/{booking}/approve',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::approve
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:248
 * @route '/mdrrmo/bookings/{booking}/approve'
 */
approve.url = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { booking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { booking: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    booking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        booking: typeof args.booking === 'object'
                ? args.booking.id
                : args.booking,
                }

    return approve.definition.url
            .replace('{booking}', parsedArgs.booking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::approve
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:248
 * @route '/mdrrmo/bookings/{booking}/approve'
 */
approve.patch = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: approve.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::approve
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:248
 * @route '/mdrrmo/bookings/{booking}/approve'
 */
    const approveForm = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::approve
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:248
 * @route '/mdrrmo/bookings/{booking}/approve'
 */
        approveForm.patch = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::reject
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:275
 * @route '/mdrrmo/bookings/{booking}/reject'
 */
export const reject = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/mdrrmo/bookings/{booking}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::reject
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:275
 * @route '/mdrrmo/bookings/{booking}/reject'
 */
reject.url = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { booking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { booking: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    booking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        booking: typeof args.booking === 'object'
                ? args.booking.id
                : args.booking,
                }

    return reject.definition.url
            .replace('{booking}', parsedArgs.booking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::reject
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:275
 * @route '/mdrrmo/bookings/{booking}/reject'
 */
reject.patch = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::reject
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:275
 * @route '/mdrrmo/bookings/{booking}/reject'
 */
    const rejectForm = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::reject
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:275
 * @route '/mdrrmo/bookings/{booking}/reject'
 */
        rejectForm.patch = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::publicMethod
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/bookings/public'
 */
export const publicMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publicMethod.url(options),
    method: 'post',
})

publicMethod.definition = {
    methods: ["post"],
    url: '/bookings/public',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::publicMethod
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/bookings/public'
 */
publicMethod.url = (options?: RouteQueryOptions) => {
    return publicMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::publicMethod
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/bookings/public'
 */
publicMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publicMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::publicMethod
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/bookings/public'
 */
    const publicMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publicMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\BookingRequestController::publicMethod
 * @see app/Http/Controllers/Mdrrmo/BookingRequestController.php:68
 * @route '/bookings/public'
 */
        publicMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publicMethod.url(options),
            method: 'post',
        })
    
    publicMethod.form = publicMethodForm
const bookings = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
show: Object.assign(show, show),
approve: Object.assign(approve, approve),
reject: Object.assign(reject, reject),
public: Object.assign(publicMethod, publicMethod),
}

export default bookings