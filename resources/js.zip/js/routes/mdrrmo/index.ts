import operations from './operations'
import ambulances from './ambulances'
import personnel from './personnel'
import bookings from './bookings'
const mdrrmo = {
    operations: Object.assign(operations, operations),
ambulances: Object.assign(ambulances, ambulances),
personnel: Object.assign(personnel, personnel),
bookings: Object.assign(bookings, bookings),
}

export default mdrrmo