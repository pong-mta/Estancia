import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::index
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:15
 * @route '/mdrrmo/ambulances'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/ambulances',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::index
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:15
 * @route '/mdrrmo/ambulances'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::index
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:15
 * @route '/mdrrmo/ambulances'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::index
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:15
 * @route '/mdrrmo/ambulances'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::index
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:15
 * @route '/mdrrmo/ambulances'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::index
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:15
 * @route '/mdrrmo/ambulances'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::index
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:15
 * @route '/mdrrmo/ambulances'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::create
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:62
 * @route '/mdrrmo/ambulances/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/ambulances/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::create
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:62
 * @route '/mdrrmo/ambulances/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::create
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:62
 * @route '/mdrrmo/ambulances/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::create
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:62
 * @route '/mdrrmo/ambulances/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::create
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:62
 * @route '/mdrrmo/ambulances/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::create
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:62
 * @route '/mdrrmo/ambulances/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::create
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:62
 * @route '/mdrrmo/ambulances/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::store
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:70
 * @route '/mdrrmo/ambulances'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/mdrrmo/ambulances',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::store
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:70
 * @route '/mdrrmo/ambulances'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::store
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:70
 * @route '/mdrrmo/ambulances'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::store
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:70
 * @route '/mdrrmo/ambulances'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::store
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:70
 * @route '/mdrrmo/ambulances'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::show
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:92
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
export const show = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/ambulances/{ambulance}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::show
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:92
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
show.url = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ambulance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ambulance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ambulance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ambulance: typeof args.ambulance === 'object'
                ? args.ambulance.id
                : args.ambulance,
                }

    return show.definition.url
            .replace('{ambulance}', parsedArgs.ambulance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::show
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:92
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
show.get = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::show
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:92
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
show.head = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::show
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:92
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
    const showForm = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::show
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:92
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
        showForm.get = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::show
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:92
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
        showForm.head = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::edit
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:101
 * @route '/mdrrmo/ambulances/{ambulance}/edit'
 */
export const edit = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/mdrrmo/ambulances/{ambulance}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::edit
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:101
 * @route '/mdrrmo/ambulances/{ambulance}/edit'
 */
edit.url = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ambulance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ambulance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ambulance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ambulance: typeof args.ambulance === 'object'
                ? args.ambulance.id
                : args.ambulance,
                }

    return edit.definition.url
            .replace('{ambulance}', parsedArgs.ambulance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::edit
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:101
 * @route '/mdrrmo/ambulances/{ambulance}/edit'
 */
edit.get = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::edit
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:101
 * @route '/mdrrmo/ambulances/{ambulance}/edit'
 */
edit.head = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::edit
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:101
 * @route '/mdrrmo/ambulances/{ambulance}/edit'
 */
    const editForm = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::edit
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:101
 * @route '/mdrrmo/ambulances/{ambulance}/edit'
 */
        editForm.get = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::edit
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:101
 * @route '/mdrrmo/ambulances/{ambulance}/edit'
 */
        editForm.head = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::update
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:110
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
export const update = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/mdrrmo/ambulances/{ambulance}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::update
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:110
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
update.url = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ambulance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ambulance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ambulance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ambulance: typeof args.ambulance === 'object'
                ? args.ambulance.id
                : args.ambulance,
                }

    return update.definition.url
            .replace('{ambulance}', parsedArgs.ambulance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::update
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:110
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
update.put = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::update
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:110
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
update.patch = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::update
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:110
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
    const updateForm = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::update
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:110
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
        updateForm.put = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::update
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:110
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
        updateForm.patch = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::destroy
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:138
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
export const destroy = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/mdrrmo/ambulances/{ambulance}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::destroy
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:138
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
destroy.url = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ambulance: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ambulance: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ambulance: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ambulance: typeof args.ambulance === 'object'
                ? args.ambulance.id
                : args.ambulance,
                }

    return destroy.definition.url
            .replace('{ambulance}', parsedArgs.ambulance.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::destroy
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:138
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
destroy.delete = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::destroy
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:138
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
    const destroyForm = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Mdrrmo\AmbulanceController::destroy
 * @see app/Http/Controllers/Mdrrmo/AmbulanceController.php:138
 * @route '/mdrrmo/ambulances/{ambulance}'
 */
        destroyForm.delete = (args: { ambulance: number | { id: number } } | [ambulance: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ambulances = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default ambulances