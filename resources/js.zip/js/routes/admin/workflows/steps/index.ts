import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::index
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:43
 * @route '/admin/workflows/{workflow}/steps'
 */
export const index = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/workflows/{workflow}/steps',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::index
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:43
 * @route '/admin/workflows/{workflow}/steps'
 */
index.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return index.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::index
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:43
 * @route '/admin/workflows/{workflow}/steps'
 */
index.get = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::index
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:43
 * @route '/admin/workflows/{workflow}/steps'
 */
index.head = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::index
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:43
 * @route '/admin/workflows/{workflow}/steps'
 */
    const indexForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::index
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:43
 * @route '/admin/workflows/{workflow}/steps'
 */
        indexForm.get = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::index
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:43
 * @route '/admin/workflows/{workflow}/steps'
 */
        indexForm.head = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::store
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:97
 * @route '/admin/workflows/{workflow}/steps'
 */
export const store = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/workflows/{workflow}/steps',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::store
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:97
 * @route '/admin/workflows/{workflow}/steps'
 */
store.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return store.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::store
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:97
 * @route '/admin/workflows/{workflow}/steps'
 */
store.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::store
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:97
 * @route '/admin/workflows/{workflow}/steps'
 */
    const storeForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::store
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:97
 * @route '/admin/workflows/{workflow}/steps'
 */
        storeForm.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::reorder
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:180
 * @route '/admin/workflows/{workflow}/steps/reorder'
 */
export const reorder = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reorder.url(args, options),
    method: 'put',
})

reorder.definition = {
    methods: ["put"],
    url: '/admin/workflows/{workflow}/steps/reorder',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::reorder
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:180
 * @route '/admin/workflows/{workflow}/steps/reorder'
 */
reorder.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return reorder.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::reorder
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:180
 * @route '/admin/workflows/{workflow}/steps/reorder'
 */
reorder.put = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reorder.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::reorder
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:180
 * @route '/admin/workflows/{workflow}/steps/reorder'
 */
    const reorderForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reorder.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::reorder
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:180
 * @route '/admin/workflows/{workflow}/steps/reorder'
 */
        reorderForm.put = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reorder.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reorder.form = reorderForm
/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::update
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:138
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
export const update = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/workflows/{workflow}/steps/{step}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::update
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:138
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
update.url = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                    step: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return update.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::update
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:138
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
update.put = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::update
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:138
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
    const updateForm = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::update
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:138
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
        updateForm.put = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::destroy
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:234
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
export const destroy = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/workflows/{workflow}/steps/{step}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::destroy
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:234
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
destroy.url = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                    step: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return destroy.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowStepController::destroy
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:234
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
destroy.delete = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::destroy
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:234
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
    const destroyForm = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowStepController::destroy
 * @see app/Http/Controllers/Admin/WorkflowStepController.php:234
 * @route '/admin/workflows/{workflow}/steps/{step}'
 */
        destroyForm.delete = (args: { workflow: number | { id: number }, step: number | { id: number } } | [workflow: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const steps = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
reorder: Object.assign(reorder, reorder),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default steps