import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import steps from './steps'
/**
* @see \App\Http\Controllers\Admin\WorkflowController::index
 * @see app/Http/Controllers/Admin/WorkflowController.php:84
 * @route '/admin/workflows'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/workflows',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowController::index
 * @see app/Http/Controllers/Admin/WorkflowController.php:84
 * @route '/admin/workflows'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowController::index
 * @see app/Http/Controllers/Admin/WorkflowController.php:84
 * @route '/admin/workflows'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\WorkflowController::index
 * @see app/Http/Controllers/Admin/WorkflowController.php:84
 * @route '/admin/workflows'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowController::index
 * @see app/Http/Controllers/Admin/WorkflowController.php:84
 * @route '/admin/workflows'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowController::index
 * @see app/Http/Controllers/Admin/WorkflowController.php:84
 * @route '/admin/workflows'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\WorkflowController::index
 * @see app/Http/Controllers/Admin/WorkflowController.php:84
 * @route '/admin/workflows'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\WorkflowController::store
 * @see app/Http/Controllers/Admin/WorkflowController.php:141
 * @route '/admin/workflows'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/workflows',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowController::store
 * @see app/Http/Controllers/Admin/WorkflowController.php:141
 * @route '/admin/workflows'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowController::store
 * @see app/Http/Controllers/Admin/WorkflowController.php:141
 * @route '/admin/workflows'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowController::store
 * @see app/Http/Controllers/Admin/WorkflowController.php:141
 * @route '/admin/workflows'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowController::store
 * @see app/Http/Controllers/Admin/WorkflowController.php:141
 * @route '/admin/workflows'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\WorkflowController::update
 * @see app/Http/Controllers/Admin/WorkflowController.php:174
 * @route '/admin/workflows/{workflow}'
 */
export const update = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/workflows/{workflow}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowController::update
 * @see app/Http/Controllers/Admin/WorkflowController.php:174
 * @route '/admin/workflows/{workflow}'
 */
update.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return update.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowController::update
 * @see app/Http/Controllers/Admin/WorkflowController.php:174
 * @route '/admin/workflows/{workflow}'
 */
update.put = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowController::update
 * @see app/Http/Controllers/Admin/WorkflowController.php:174
 * @route '/admin/workflows/{workflow}'
 */
    const updateForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowController::update
 * @see app/Http/Controllers/Admin/WorkflowController.php:174
 * @route '/admin/workflows/{workflow}'
 */
        updateForm.put = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\WorkflowController::publish
 * @see app/Http/Controllers/Admin/WorkflowController.php:208
 * @route '/admin/workflows/{workflow}/publish'
 */
export const publish = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/admin/workflows/{workflow}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowController::publish
 * @see app/Http/Controllers/Admin/WorkflowController.php:208
 * @route '/admin/workflows/{workflow}/publish'
 */
publish.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return publish.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowController::publish
 * @see app/Http/Controllers/Admin/WorkflowController.php:208
 * @route '/admin/workflows/{workflow}/publish'
 */
publish.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowController::publish
 * @see app/Http/Controllers/Admin/WorkflowController.php:208
 * @route '/admin/workflows/{workflow}/publish'
 */
    const publishForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowController::publish
 * @see app/Http/Controllers/Admin/WorkflowController.php:208
 * @route '/admin/workflows/{workflow}/publish'
 */
        publishForm.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, options),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\Admin\WorkflowController::newVersion
 * @see app/Http/Controllers/Admin/WorkflowController.php:310
 * @route '/admin/workflows/{workflow}/new-version'
 */
export const newVersion = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: newVersion.url(args, options),
    method: 'post',
})

newVersion.definition = {
    methods: ["post"],
    url: '/admin/workflows/{workflow}/new-version',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowController::newVersion
 * @see app/Http/Controllers/Admin/WorkflowController.php:310
 * @route '/admin/workflows/{workflow}/new-version'
 */
newVersion.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return newVersion.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowController::newVersion
 * @see app/Http/Controllers/Admin/WorkflowController.php:310
 * @route '/admin/workflows/{workflow}/new-version'
 */
newVersion.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: newVersion.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowController::newVersion
 * @see app/Http/Controllers/Admin/WorkflowController.php:310
 * @route '/admin/workflows/{workflow}/new-version'
 */
    const newVersionForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: newVersion.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowController::newVersion
 * @see app/Http/Controllers/Admin/WorkflowController.php:310
 * @route '/admin/workflows/{workflow}/new-version'
 */
        newVersionForm.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: newVersion.url(args, options),
            method: 'post',
        })
    
    newVersion.form = newVersionForm
/**
* @see \App\Http\Controllers\Admin\WorkflowController::history
 * @see app/Http/Controllers/Admin/WorkflowController.php:349
 * @route '/admin/workflows/{workflow}/history'
 */
export const history = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/admin/workflows/{workflow}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowController::history
 * @see app/Http/Controllers/Admin/WorkflowController.php:349
 * @route '/admin/workflows/{workflow}/history'
 */
history.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return history.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowController::history
 * @see app/Http/Controllers/Admin/WorkflowController.php:349
 * @route '/admin/workflows/{workflow}/history'
 */
history.get = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\WorkflowController::history
 * @see app/Http/Controllers/Admin/WorkflowController.php:349
 * @route '/admin/workflows/{workflow}/history'
 */
history.head = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowController::history
 * @see app/Http/Controllers/Admin/WorkflowController.php:349
 * @route '/admin/workflows/{workflow}/history'
 */
    const historyForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: history.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowController::history
 * @see app/Http/Controllers/Admin/WorkflowController.php:349
 * @route '/admin/workflows/{workflow}/history'
 */
        historyForm.get = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\WorkflowController::history
 * @see app/Http/Controllers/Admin/WorkflowController.php:349
 * @route '/admin/workflows/{workflow}/history'
 */
        historyForm.head = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    history.form = historyForm
const workflows = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
steps: Object.assign(steps, steps),
publish: Object.assign(publish, publish),
newVersion: Object.assign(newVersion, newVersion),
history: Object.assign(history, history),
}

export default workflows