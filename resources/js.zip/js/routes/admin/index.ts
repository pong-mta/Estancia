import offices from './offices'
import users from './users'
import workflows from './workflows'
import documentWorkflows from './document-workflows'
import documents from './documents'
import attachments from './attachments'
import pendingApprovals from './pending-approvals'
import documentHistory from './document-history'
import procurement from './procurement'
import suppliers from './suppliers'
const admin = {
    offices: Object.assign(offices, offices),
users: Object.assign(users, users),
workflows: Object.assign(workflows, workflows),
documentWorkflows: Object.assign(documentWorkflows, documentWorkflows),
documents: Object.assign(documents, documents),
attachments: Object.assign(attachments, attachments),
pendingApprovals: Object.assign(pendingApprovals, pendingApprovals),
documentHistory: Object.assign(documentHistory, documentHistory),
procurement: Object.assign(procurement, procurement),
suppliers: Object.assign(suppliers, suppliers),
}

export default admin