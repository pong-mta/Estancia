import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::approve
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:21
 * @route '/admin/document-workflows/{documentWorkflow}/approve'
 */
export const approve = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/document-workflows/{documentWorkflow}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::approve
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:21
 * @route '/admin/document-workflows/{documentWorkflow}/approve'
 */
approve.url = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { documentWorkflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { documentWorkflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    documentWorkflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        documentWorkflow: typeof args.documentWorkflow === 'object'
                ? args.documentWorkflow.id
                : args.documentWorkflow,
                }

    return approve.definition.url
            .replace('{documentWorkflow}', parsedArgs.documentWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::approve
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:21
 * @route '/admin/document-workflows/{documentWorkflow}/approve'
 */
approve.post = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowActionController::approve
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:21
 * @route '/admin/document-workflows/{documentWorkflow}/approve'
 */
    const approveForm = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowActionController::approve
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:21
 * @route '/admin/document-workflows/{documentWorkflow}/approve'
 */
        approveForm.post = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::reject
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:29
 * @route '/admin/document-workflows/{documentWorkflow}/reject'
 */
export const reject = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/document-workflows/{documentWorkflow}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::reject
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:29
 * @route '/admin/document-workflows/{documentWorkflow}/reject'
 */
reject.url = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { documentWorkflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { documentWorkflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    documentWorkflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        documentWorkflow: typeof args.documentWorkflow === 'object'
                ? args.documentWorkflow.id
                : args.documentWorkflow,
                }

    return reject.definition.url
            .replace('{documentWorkflow}', parsedArgs.documentWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::reject
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:29
 * @route '/admin/document-workflows/{documentWorkflow}/reject'
 */
reject.post = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowActionController::reject
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:29
 * @route '/admin/document-workflows/{documentWorkflow}/reject'
 */
    const rejectForm = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowActionController::reject
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:29
 * @route '/admin/document-workflows/{documentWorkflow}/reject'
 */
        rejectForm.post = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::budgetReview
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:40
 * @route '/admin/document-workflows/{documentWorkflow}/budget-review'
 */
export const budgetReview = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: budgetReview.url(args, options),
    method: 'post',
})

budgetReview.definition = {
    methods: ["post"],
    url: '/admin/document-workflows/{documentWorkflow}/budget-review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::budgetReview
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:40
 * @route '/admin/document-workflows/{documentWorkflow}/budget-review'
 */
budgetReview.url = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { documentWorkflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { documentWorkflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    documentWorkflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        documentWorkflow: typeof args.documentWorkflow === 'object'
                ? args.documentWorkflow.id
                : args.documentWorkflow,
                }

    return budgetReview.definition.url
            .replace('{documentWorkflow}', parsedArgs.documentWorkflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WorkflowActionController::budgetReview
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:40
 * @route '/admin/document-workflows/{documentWorkflow}/budget-review'
 */
budgetReview.post = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: budgetReview.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WorkflowActionController::budgetReview
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:40
 * @route '/admin/document-workflows/{documentWorkflow}/budget-review'
 */
    const budgetReviewForm = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: budgetReview.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WorkflowActionController::budgetReview
 * @see app/Http/Controllers/Admin/WorkflowActionController.php:40
 * @route '/admin/document-workflows/{documentWorkflow}/budget-review'
 */
        budgetReviewForm.post = (args: { documentWorkflow: number | { id: number } } | [documentWorkflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: budgetReview.url(args, options),
            method: 'post',
        })
    
    budgetReview.form = budgetReviewForm
const documentWorkflows = {
    approve: Object.assign(approve, approve),
reject: Object.assign(reject, reject),
budgetReview: Object.assign(budgetReview, budgetReview),
}

export default documentWorkflows