import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import quotations from './quotations'
/**
* @see \App\Http\Controllers\Admin\ProcurementController::index
 * @see app/Http/Controllers/Admin/ProcurementController.php:17
 * @route '/admin/procurement'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/procurement',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProcurementController::index
 * @see app/Http/Controllers/Admin/ProcurementController.php:17
 * @route '/admin/procurement'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcurementController::index
 * @see app/Http/Controllers/Admin/ProcurementController.php:17
 * @route '/admin/procurement'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProcurementController::index
 * @see app/Http/Controllers/Admin/ProcurementController.php:17
 * @route '/admin/procurement'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProcurementController::index
 * @see app/Http/Controllers/Admin/ProcurementController.php:17
 * @route '/admin/procurement'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcurementController::index
 * @see app/Http/Controllers/Admin/ProcurementController.php:17
 * @route '/admin/procurement'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProcurementController::index
 * @see app/Http/Controllers/Admin/ProcurementController.php:17
 * @route '/admin/procurement'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ProcurementController::start
 * @see app/Http/Controllers/Admin/ProcurementController.php:55
 * @route '/admin/procurement/{document}/start'
 */
export const start = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/admin/procurement/{document}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ProcurementController::start
 * @see app/Http/Controllers/Admin/ProcurementController.php:55
 * @route '/admin/procurement/{document}/start'
 */
start.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { document: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return start.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcurementController::start
 * @see app/Http/Controllers/Admin/ProcurementController.php:55
 * @route '/admin/procurement/{document}/start'
 */
start.post = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ProcurementController::start
 * @see app/Http/Controllers/Admin/ProcurementController.php:55
 * @route '/admin/procurement/{document}/start'
 */
    const startForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcurementController::start
 * @see app/Http/Controllers/Admin/ProcurementController.php:55
 * @route '/admin/procurement/{document}/start'
 */
        startForm.post = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Admin\ProcurementController::show
 * @see app/Http/Controllers/Admin/ProcurementController.php:86
 * @route '/admin/procurement/{procurement}'
 */
export const show = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/procurement/{procurement}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProcurementController::show
 * @see app/Http/Controllers/Admin/ProcurementController.php:86
 * @route '/admin/procurement/{procurement}'
 */
show.url = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { procurement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { procurement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    procurement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        procurement: typeof args.procurement === 'object'
                ? args.procurement.id
                : args.procurement,
                }

    return show.definition.url
            .replace('{procurement}', parsedArgs.procurement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProcurementController::show
 * @see app/Http/Controllers/Admin/ProcurementController.php:86
 * @route '/admin/procurement/{procurement}'
 */
show.get = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ProcurementController::show
 * @see app/Http/Controllers/Admin/ProcurementController.php:86
 * @route '/admin/procurement/{procurement}'
 */
show.head = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ProcurementController::show
 * @see app/Http/Controllers/Admin/ProcurementController.php:86
 * @route '/admin/procurement/{procurement}'
 */
    const showForm = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ProcurementController::show
 * @see app/Http/Controllers/Admin/ProcurementController.php:86
 * @route '/admin/procurement/{procurement}'
 */
        showForm.get = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ProcurementController::show
 * @see app/Http/Controllers/Admin/ProcurementController.php:86
 * @route '/admin/procurement/{procurement}'
 */
        showForm.head = (args: { procurement: number | { id: number } } | [procurement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const procurement = {
    index: Object.assign(index, index),
start: Object.assign(start, start),
show: Object.assign(show, show),
quotations: Object.assign(quotations, quotations),
}

export default procurement