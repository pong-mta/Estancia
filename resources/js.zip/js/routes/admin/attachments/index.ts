import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::view
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:16
 * @route '/admin/attachments/{attachment}/view'
 */
export const view = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(args, options),
    method: 'get',
})

view.definition = {
    methods: ["get","head"],
    url: '/admin/attachments/{attachment}/view',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::view
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:16
 * @route '/admin/attachments/{attachment}/view'
 */
view.url = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    attachment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment: args.attachment,
                }

    return view.definition.url
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::view
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:16
 * @route '/admin/attachments/{attachment}/view'
 */
view.get = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: view.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::view
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:16
 * @route '/admin/attachments/{attachment}/view'
 */
view.head = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: view.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::view
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:16
 * @route '/admin/attachments/{attachment}/view'
 */
    const viewForm = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: view.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::view
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:16
 * @route '/admin/attachments/{attachment}/view'
 */
        viewForm.get = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: view.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::view
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:16
 * @route '/admin/attachments/{attachment}/view'
 */
        viewForm.head = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: view.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    view.form = viewForm
/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::download
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:65
 * @route '/admin/attachments/{attachment}/download'
 */
export const download = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/admin/attachments/{attachment}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::download
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:65
 * @route '/admin/attachments/{attachment}/download'
 */
download.url = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    attachment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment: args.attachment,
                }

    return download.definition.url
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::download
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:65
 * @route '/admin/attachments/{attachment}/download'
 */
download.get = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::download
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:65
 * @route '/admin/attachments/{attachment}/download'
 */
download.head = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::download
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:65
 * @route '/admin/attachments/{attachment}/download'
 */
    const downloadForm = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::download
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:65
 * @route '/admin/attachments/{attachment}/download'
 */
        downloadForm.get = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DocumentAttachmentController::download
 * @see app/Http/Controllers/Admin/DocumentAttachmentController.php:65
 * @route '/admin/attachments/{attachment}/download'
 */
        downloadForm.head = (args: { attachment: string | number } | [attachment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const attachments = {
    view: Object.assign(view, view),
download: Object.assign(download, download),
}

export default attachments